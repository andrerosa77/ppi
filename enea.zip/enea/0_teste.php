<!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">
  
</head>
<body>

  
   <div class="container">
	    	
	    	<br /><br />

	    	<div class="col-md-2"></div>
	    	<div class="col-md-8" id="divlogin">
	    		<h3 align="center">Importante!</h3>
	    		<br />
				<form method="post" action="" id="acesso">
					<div class="form-group">
						<div class="well well-sm"><strong> Orientações antes de inciar o teste</strong>
							<p>Classifique as afirmações ao lado conforme sua aplicabilidade com base na seguinte escala:</p>

							<table class="table table-hover">
    <thead>
      <tr>
        <th>Escala</th>
       
      </tr>
    </thead>
    <tbody>
      <tr class="danger">
        <td>01 - Nunca é verdadeira</td>   
      </tr>
      <tr class="warning">
        <td>02 - Raramente é verdadeira</td>   
      </tr>
      <tr class="active">
        <td>03 - Em parte é verdadeira</td>   
      </tr>
       <tr class="info">
        <td>04 - Geralmente é verdadeira</td>   
      </tr>
       <tr class="success">
        <td>05 - Sempre é verdadeira</td>   
      </tr>
    </tbody>
  </table>
  <button type="submit" class="btn btn-primary form-control">Começar</button>
</div>
				</form>
</div>


	


 <?php include 'footer.html';?>

 </body>
</html>