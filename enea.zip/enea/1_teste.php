<!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">
  
</head>
<body>

  
   <div class="container">
	    	
	    	<br /><br />

	    	<div class="col-md-2"></div>
	    	<div class="col-md-8" id="divlogin">
	    		<h3 align="center">Teste</h3>
	    		<br />
				<form method="post" action="grava_teste.php" id="acesso">
					<div class="form-group">
						<div class="well well-sm"><strong>Etapa 1 de 9</strong><br><br>

						<input type="text" id="etapa" value="1" name="etapa" hidden="">

						<label><h5>	<strong>Pergunta 	1	:</strong>	A maioria das pessoas me vê como alguém sério e sensato - e, no fim das contas, creio que sou assim mesmo.	A maioria das pessoas me vê como alguém sério e sensato - e, no fim das contas, creio que sou assim mesmo.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="1" name="1" value="1"> 01
						<input type="radio" id="1" name="1" value="2"> 02
						<input type="radio" id="1" name="1" value="3"> 03
						<input type="radio" id="1" name="1" value="4"> 04
						<input type="radio" id="1" name="1" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	2	:</strong>Sempre procurei ser honesto e objetivo com relação a mim mesmo e estou decidido a seguir minha consciência, não importa a que preço.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="2" name="2" value="1"> 01
						<input type="radio" id="2" name="2" value="2"> 02
						<input type="radio" id="2" name="2" value="3"> 03
						<input type="radio" id="2" name="2" value="4"> 04
						<input type="radio" id="2" name="2" value="5"> 05
						</div>
						<hr></hr>
						
						</label>

						<label><h5>	<strong>Pergunta 	3	:</strong>Embora eu possa ter um lado desregrado, de modo geral ele nunca foi a tônica de meu estilo.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="3" name="3" value="1"> 01
						<input type="radio" id="3"name="3" value="2"> 02
						<input type="radio" id="3" name="3" value="3"> 03
						<input type="radio" id="3" name="3" value="4"> 04
						<input type="radio" id="3" name="3" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	4	:</strong>Parece que há um juiz dentro de minha mente: às vezes ele é ponderado e sábio, mas em muitas ocasiões é simplesmente rígido e severo.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="4" name="4" value="1"> 01
						<input type="radio" id="4" name="4" value="2"> 02
						<input type="radio" id="4" name="4" value="3"> 03
						<input type="radio" id="4" name="4" value="4"> 04
						<input type="radio" id="4" name="4" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	5	:</strong>Acho que paguei um preço muito alto por tentar ser perfeito.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="5" name="5" value="1"> 01
						<input type="radio" id="5" name="5" value="2"> 02
						<input type="radio" id="5" name="5" value="3"> 03
						<input type="radio" id="5" name="5" value="4"> 04
						<input type="radio" id="5" name="5" value="5"> 05
						</div>
						<hr></hr>
						</label>
						
						<label><h5>	<strong>Pergunta 	6	:</strong>Gosto de rir como qualquer pessoa - deveria rir mais!

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="6" name="6" value="1"> 01
						<input type="radio" id="6" name="6" value="2"> 02
						<input type="radio" id="6" name="6" value="3"> 03
						<input type="radio" id="6" name="6" value="4"> 04
						<input type="radio" id="6" name="6" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	7	:</strong>Meus princípios e ideais inspiram-me a realizações maiores e dão sentido e valor à minha vida.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="7" name="7" value="1"> 01
						<input type="radio" id="7" name="7" value="2"> 02
						<input type="radio" id="7" name="7" value="3"> 03
						<input type="radio" id="7" name="7" value="4"> 04
						<input type="radio" id="7" name="7" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	8	:</strong>Não entendo como tanta gente tem padrões tão lassos (soltos).

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="8" name="8" value="1"> 01
						<input type="radio" id="8" name="8" value="2"> 02
						<input type="radio" id="8" name="8" value="3"> 03
						<input type="radio" id="8" name="8" value="4"> 04
						<input type="radio" id="8" name="8" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	9	:</strong>As coisas dependem tanto de mim para serem  feitas que tenho de ser mais organizado e metódico que todo mundo.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="9" name="9" value="1"> 01
						<input type="radio" id="9" name="9" value="2"> 02
						<input type="radio" id="9" name="9" value="3"> 03
						<input type="radio" id="9" name="9" value="4"> 04
						<input type="radio" id="9" name="9" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	10	:</strong>Tenho a impressão de possuir uma missão, talvez até uma vocação p/ algo mais sublime, e acho que posso atingir alguma coisa extraordinária na vida.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="10" name="10" value="1"> 01
						<input type="radio" id="10" name="10" value="2"> 02
						<input type="radio" id="10" name="10" value="3"> 03
						<input type="radio" id="10" name="10" value="4"> 04
						<input type="radio" id="10" name="10" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	11	:</strong>Detesto erros e, por isso, geralmente sou extremamente rigoroso para certificar-me de que as coisas estão sendo feitas como devem.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="11" name="11" value="1"> 01
						<input type="radio" id="11" name="11" value="2"> 02
						<input type="radio" id="11" name="11" value="3"> 03
						<input type="radio" id="11" name="11" value="4"> 04
						<input type="radio" id="11" name="11" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	12	:</strong>Em poucas palavras, há muito tempo venho acreditando que o certo é certo e o errado é errado.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="12" name="12" value="1"> 01
						<input type="radio" id="12" name="12" value="2"> 02
						<input type="radio" id="12" name="12" value="3"> 03
						<input type="radio" id="12" name="12" value="4"> 04
						<input type="radio" id="12" name="12" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	13	:</strong>Pra mim é difícil contentar-me com as coisas do jeito que são; não tenho medo que piorem com minha interferência.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="13" name="13" value="1"> 01
						<input type="radio" id="13" name="13" value="2"> 02
						<input type="radio" id="13" name="13" value="3"> 03
						<input type="radio" id="13" name="13" value="4"> 04
						<input type="radio" id="13" name="13" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	14	:</strong>Tenho sobre os ombros muitas responsabilidades; Deus sabe o que aconteceria se não estivesse à altura das expectativas.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="14" name="14" value="1"> 01
						<input type="radio" id="14" name="14" value="2"> 02
						<input type="radio" id="14" name="14" value="3"> 03
						<input type="radio" id="14" name="14" value="4"> 04
						<input type="radio" id="14" name="14" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	15	:</strong>Manter a elegância e a natureza mesmo sob pressão é algo que sempre me comove.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="15" name="15" value="1"> 01
						<input type="radio" id="15" name="15" value="2"> 02
						<input type="radio" id="15" name="15" value="3"> 03
						<input type="radio" id="15" name="15" value="4"> 04
						<input type="radio" id="15" name="15" value="5"> 05
						</div>
						<hr></hr>
						</label>
  <button type="submit" class="btn btn-primary form-control">Enviar Dados</button>
</div>
				</form>
</div>


	


 <?php include 'footer.html';?>

 </body>
</html>