<!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">
  
</head>
<body>

  
   <div class="container">
	    	
	    	<br /><br />

	    	<div class="col-md-2"></div>
	    	<div class="col-md-8" id="divlogin">
	    		<h3 align="center">Teste</h3>
	    		<br />
				<form method="post" action="grava_teste.php" id="acesso">
					<div class="form-group">
						<div class="well well-sm"><strong>Etapa 2 de 9</strong><br><br>

						<input type="text" id="etapa" value="2" name="etapa" hidden="">

						<label><h5>	<strong>Pergunta 	16	:</strong>Meu interesse pelas pessoas leva-me a envolver-me profundamente com elas – com seus sonhos, esperanças e necessidades.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="16" name="16" value="1"> 01
						<input type="radio" id="16" name="16" value="2"> 02
						<input type="radio" id="16" name="16" value="3"> 03
						<input type="radio" id="16" name="16" value="4"> 04
						<input type="radio" id="16" name="16" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	17	:</strong>Para mim, ser amigável é natural: puxo conversa facilmente e chamo todo mundo pelo prenome.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="17" name="17" value="1"> 01
						<input type="radio" id="17" name="17" value="2"> 02
						<input type="radio" id="17" name="17" value="3"> 03
						<input type="radio" id="17" name="17" value="4"> 04
						<input type="radio" id="17" name="17" value="5"> 05
						</div>
						<hr></hr>
						
						</label>

						<label><h5>	<strong>Pergunta 	18	:</strong>Descobri que as pessoas reagem com afeto quando lhes dou atenção e incentivo.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="18" name="18" value="1"> 01
						<input type="radio" id="18" name="18" value="2"> 02
						<input type="radio" id="18" name="18" value="3"> 03
						<input type="radio" id="18" name="18" value="4"> 04
						<input type="radio" id="18" name="18" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	19	:</strong>Não posso ver um cachorro sem dono que já quero levar para casa.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="19" name="19" value="1"> 01
						<input type="radio" id="19" name="19" value="2"> 02
						<input type="radio" id="19" name="19" value="3"> 03
						<input type="radio" id="19" name="19" value="4"> 04
						<input type="radio" id="19" name="19" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	20	:</strong>O fato de ser uma pessoa atenciosa e generosa me faz sentir bem.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="20" name="20" value="1"> 01
						<input type="radio" id="20" name="20" value="2"> 02
						<input type="radio" id="20" name="20" value="3"> 03
						<input type="radio" id="20" name="20" value="4"> 04
						<input type="radio" id="20" name="20" value="5"> 05
						</div>
						<hr></hr>
						</label>
						
						<label><h5>	<strong>Pergunta 	21	:</strong>Não sou de alegar o bem que faço às pessoas, mas fico muito chateado se eles não reconhecerem ou não se importarem com isso.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="21" name="21" value="1"> 01
						<input type="radio" id="21" name="21" value="2"> 02
						<input type="radio" id="21" name="21" value="3"> 03
						<input type="radio" id="21" name="21" value="4"> 04
						<input type="radio" id="21" name="21" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	22	:</strong>É verdade que muitas vezes faço mais pelos outros do que deveria – dou demais e não penso muito em mim mesmo.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="22" name="22" value="1"> 01
						<input type="radio" id="22" name="22" value="2"> 02
						<input type="radio" id="22" name="22" value="3"> 03
						<input type="radio" id="22" name="22" value="4"> 04
						<input type="radio" id="22" name="22" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	23	:</strong>Quase sempre me vejo tentando conquistar as pessoas, especialmente se, a princípio, elas parecem indiferentes.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="23" name="23" value="1"> 01
						<input type="radio" id="23" name="23" value="2"> 02
						<input type="radio" id="23" name="23" value="3"> 03
						<input type="radio" id="23" name="23" value="4"> 04
						<input type="radio" id="23" name="23" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	24	:</strong>ATenho um prazer em especial e entreter meus amigos e toda a minha “grande família”.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="24" name="24" value="1"> 01
						<input type="radio" id="24" name="24" value="2"> 02
						<input type="radio" id="24" name="24" value="3"> 03
						<input type="radio" id="24" name="24" value="4"> 04
						<input type="radio" id="24" name="24" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	25	:</strong>Posso ser afetuoso e ajudar as pessoas, mas sou mais forte do que pareço.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="25" name="25" value="1"> 01
						<input type="radio" id="25" name="25" value="2"> 02
						<input type="radio" id="25" name="25" value="3"> 03
						<input type="radio" id="25" name="25" value="4"> 04
						<input type="radio" id="25" name="25" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	26	:</strong>Consigo manifestar meus sentimentos mais abertamente que a maioria.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="26" name="26" value="1"> 01
						<input type="radio" id="26" name="26" value="2"> 02
						<input type="radio" id="26" name="26" value="3"> 03
						<input type="radio" id="26" name="26" value="4"> 04
						<input type="radio" id="26" name="26" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	27	:</strong>Sou capaz de sair de meu caminho para saber o que está acontecendo com as pessoas de quem eu gosto.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="27" name="27" value="1"> 01
						<input type="radio" id="27" name="27" value="2"> 02
						<input type="radio" id="27" name="27" value="3"> 03
						<input type="radio" id="27" name="27" value="4"> 04
						<input type="radio" id="27" name="27" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	28	:</strong>Veja a mim mesmo como um “reparador de corações partidos”.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="28" name="28" value="1"> 01
						<input type="radio" id="28" name="28" value="2"> 02
						<input type="radio" id="28" name="28" value="3"> 03
						<input type="radio" id="28" name="28" value="4"> 04
						<input type="radio" id="28" name="28" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	29	:</strong>Minha saúde e meu bolso já sofreram muitas vezes por eu ter colocado as necessidades e os interesses dos outros acima dos meus.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="29" name="29" value="1"> 01
						<input type="radio" id="29" name="29" value="2"> 02
						<input type="radio" id="29" name="29" value="3"> 03
						<input type="radio" id="29" name="29" value="4"> 04
						<input type="radio" id="29" name="29" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	30	:</strong>Adoro me desdobrar para fazer as pessoas se sentirem bem vindas e queridas.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="30" name="30" value="1"> 01
						<input type="radio" id="30" name="30" value="2"> 02
						<input type="radio" id="30" name="30" value="3"> 03
						<input type="radio" id="30" name="30" value="4"> 04
						<input type="radio" id="30" name="30" value="5"> 05
						</div>
						<hr></hr>
						</label>
  <button type="submit" class="btn btn-primary form-control">Enviar Dados</button>
</div>
				</form>
</div>


	


 <?php include 'footer.html';?>

 </body>
</html>