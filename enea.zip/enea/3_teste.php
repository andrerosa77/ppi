<!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">
  
</head>
<body>

  
   <div class="container">
	    	
	    	<br /><br />

	    	<div class="col-md-2"></div>
	    	<div class="col-md-8" id="divlogin">
	    		<h3 align="center">Teste</h3>
	    		<br />
				<form method="post" action="grava_teste.php" id="acesso">
					<div class="form-group">
						<div class="well well-sm"><strong>Etapa 3 de 9</strong><br><br>

						<input type="text" id="etapa" value="3" name="etapa" hidden="">

						<label><h5>	<strong>Pergunta 	31	:</strong>Vejo-me como uma pessoa extremamente competente: fico muito aborrecido se não sou, no mínimo, eficiente.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="31" name="31" value="1"> 01
						<input type="radio" id="31" name="31" value="2"> 02
						<input type="radio" id="31" name="31" value="3"> 03
						<input type="radio" id="31" name="31" value="4"> 04
						<input type="radio" id="31" name="31" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	32	:</strong>Quando as coisas vão bem, eu praticamente “irradio” uma espécie de alegria interior em ser quem sou e ter a vida que tenho.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="32" name="32" value="1"> 01
						<input type="radio" id="32" name="32" value="2"> 02
						<input type="radio" id="32" name="32" value="3"> 03
						<input type="radio" id="32" name="32" value="4"> 04
						<input type="radio" id="32" name="32" value="5"> 05
						</div>
						<hr></hr>
						
						</label>

						<label><h5>	<strong>Pergunta 	33	:</strong>Tento apresentar-me da melhor maneira possível – mas não é isso o que todos fazem?

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="33" name="33" value="1"> 01
						<input type="radio" id="33" name="33" value="2"> 02
						<input type="radio" id="33" name="33" value="3"> 03
						<input type="radio" id="33" name="33" value="4"> 04
						<input type="radio" id="33" name="33" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	34	:</strong>Meus sentimentos me parecem estranhos a mim mesmo – eu sinto as coisas com toda a força por algum tempo e depois as esqueço.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="34" name="34" value="1"> 01
						<input type="radio" id="34" name="34" value="2"> 02
						<input type="radio" id="34" name="34" value="3"> 03
						<input type="radio" id="34" name="34" value="4"> 04
						<input type="radio" id="34" name="34" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	35	:</strong>Para mim é importante ser bem sucedido, mesmo que ainda não tenha todo o sucesso que desejo.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="35" name="35" value="1"> 01
						<input type="radio" id="35" name="35" value="2"> 02
						<input type="radio" id="35" name="35" value="3"> 03
						<input type="radio" id="35" name="35" value="4"> 04
						<input type="radio" id="35" name="35" value="5"> 05
						</div>
						<hr></hr>
						</label>
						
						<label><h5>	<strong>Pergunta 	36	:</strong>Seja isso bom ou mau, sei esconder minhas inseguranças muito bem – as pessoas jamais adivinhariam o que estou sentindo!
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="36" name="36" value="1"> 01
						<input type="radio" id="36" name="36" value="2"> 02
						<input type="radio" id="36" name="36" value="3"> 03
						<input type="radio" id="36" name="36" value="4"> 04
						<input type="radio" id="36" name="36" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	37	:</strong>Quero causar sempre boa impressão; por isso geralmente sou gentil, educado e amigável.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="37" name="37" value="1"> 01
						<input type="radio" id="37" name="37" value="2"> 02
						<input type="radio" id="37" name="37" value="3"> 03
						<input type="radio" id="37" name="37" value="4"> 04
						<input type="radio" id="37" name="37" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	38	:</strong>Estou sempre a par de como meus colegas e amigos estão se saindo e tendo a comparar-me com eles.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="38" name="38" value="1"> 01
						<input type="radio" id="38" name="38" value="2"> 02
						<input type="radio" id="38" name="38" value="3"> 03
						<input type="radio" id="38" name="38" value="4"> 04
						<input type="radio" id="38" name="38" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	39	:</strong>Procuro lutar para ser o melhor no que faço ,quando não posso destacar-me em alguma coisa, nem lhe dou atenção.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="39" name="39" value="1"> 01
						<input type="radio" id="39" name="39" value="2"> 02
						<input type="radio" id="39" name="39" value="3"> 03
						<input type="radio" id="39" name="39" value="4"> 04
						<input type="radio" id="39" name="39" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	40	:</strong>Algumas vezes tive de simplificar as coisas para atingir minhas metas.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="40" name="40" value="1"> 01
						<input type="radio" id="40" name="40" value="2"> 02
						<input type="radio" id="40" name="40" value="3"> 03
						<input type="radio" id="40" name="40" value="4"> 04
						<input type="radio" id="40" name="40" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	41	:</strong>Quando me sinto inseguro, fico distante e frio com as pessoas.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="41" name="41" value="1"> 01
						<input type="radio" id="41" name="41" value="2"> 02
						<input type="radio" id="41" name="41" value="3"> 03
						<input type="radio" id="41" name="41" value="4"> 04
						<input type="radio" id="41" name="41" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	42	:</strong>Fico muito aborrecido quando as pessoas não conhecem a excelência do que faço.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="42" name="42" value="1"> 01
						<input type="radio" id="42" name="42" value="2"> 02
						<input type="radio" id="42" name="42" value="3"> 03
						<input type="radio" id="42" name="42" value="4"> 04
						<input type="radio" id="42" name="42" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	43	:</strong>Sou mais adaptável que a maioria: se as coisas não dão certo, sei mudar meu comportamento para obter os resultados que pretendo.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="43" name="43" value="1"> 01
						<input type="radio" id="43" name="43" value="2"> 02
						<input type="radio" id="43" name="43" value="3"> 03
						<input type="radio" id="43" name="43" value="4"> 04
						<input type="radio" id="43" name="43" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta    44	:</strong>Sempre tenho algum objetivo em mente e sei como motivar-me para atingi-lo.
						</h5>	
					    <br>44
						<div  align="center">

						<input type="radio" id="44" name="44" value="1"> 01
						<input type="radio" id="44" name="44" value="2"> 02
						<input type="radio" id="44" name="44" value="3"> 03
						<input type="radio" id="44" name="44" value="4"> 04
						<input type="radio" id="44" name="44" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	45	:</strong>Sou um pouco viciado em trabalho – fico perdido quando não estou realizando coisas.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="45" name="45" value="1"> 01
						<input type="radio" id="45" name="45" value="2"> 02
						<input type="radio" id="45" name="45" value="3"> 03
						<input type="radio" id="45" name="45" value="4"> 04
						<input type="radio" id="45" name="45" value="5"> 05
						</div>
						<hr></hr>
						</label>
  <button type="submit" class="btn btn-primary form-control">Enviar Dados</button>
</div>
				</form>
</div>


	


 <?php include 'footer.html';?>

 </body>
</html>