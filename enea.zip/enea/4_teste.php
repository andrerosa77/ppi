<!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">
  
</head>
<body>

  
   <div class="container">
	    	
	    	<br /><br />

	    	<div class="col-md-2"></div>
	    	<div class="col-md-8" id="divlogin">
	    		<h3 align="center">Teste</h3>
	    		<br />
				<form method="post" action="grava_teste.php" id="acesso">
					<div class="form-group">
						<div class="well well-sm"><strong>Etapa 4 de 9</strong><br><br>

						<input type="text" id="etapa" value="4" name="etapa" hidden="">

						<label><h5>	<strong>Pergunta 	46	:</strong>Muita gente me acha enigmático, difícil e contraditório –  e eu gosto de ser assim!
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="46" name="46" value="1"> 01
						<input type="radio" id="46" name="46" value="2"> 02
						<input type="radio" id="46" name="46" value="3"> 03
						<input type="radio" id="46" name="46" value="4"> 04
						<input type="radio" id="46" name="46" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	47	:</strong>Geralmente remôo os sentimentos negativos muito tempo antes de conseguir livrar-me deles.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="47" name="47" value="1"> 01
						<input type="radio" id="47" name="47" value="2"> 02
						<input type="radio" id="47" name="47" value="3"> 03
						<input type="radio" id="47" name="47" value="4"> 04
						<input type="radio" id="47" name="47" value="5"> 05
						</div>
						<hr></hr>
						
						</label>

						<label><h5>	<strong>Pergunta 	48	:</strong>Costumo sentir-me solitário e sozinho mesmo quando estou com as pessoas mais próximas.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="48" name="48" value="1"> 01
						<input type="radio" id="48" name="48" value="2"> 02
						<input type="radio" id="48" name="48" value="3"> 03
						<input type="radio" id="48" name="48" value="4"> 04
						<input type="radio" id="48" name="48" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	49	:</strong>Quando sou criticado ou mal interpretado, costumo retrair-me e ficar amuado.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="49" name="49" value="1"> 01
						<input type="radio" id="49" name="49" value="2"> 02
						<input type="radio" id="49" name="49" value="3"> 03
						<input type="radio" id="49" name="49" value="4"> 04
						<input type="radio" id="49" name="49" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	50	:</strong>Para mim é difícil envolver-me com as coisas quando não tenho controle criativo sobre elas.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="50" name="50" value="1"> 01
						<input type="radio" id="50" name="50" value="2"> 02
						<input type="radio" id="50" name="50" value="3"> 03
						<input type="radio" id="50" name="50" value="4"> 04
						<input type="radio" id="50" name="50" value="5"> 05
						</div>
						<hr></hr>
						</label>
						
						<label><h5>	<strong>Pergunta 	51	:</strong>Geralmente não sigo regras nem correspondo a expectativas porque quero dar meu toque pessoal  aquilo que faço.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="51" name="51" value="1"> 01
						<input type="radio" id="51" name="51" value="2"> 02
						<input type="radio" id="51" name="51" value="3"> 03
						<input type="radio" id="51" name="51" value="4"> 04
						<input type="radio" id="51" name="51" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	52	:</strong>Segundo a maioria dos padrões, sou bastante dramático e temperamental.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="52" name="52" value="1"> 01
						<input type="radio" id="52" name="52" value="2"> 02
						<input type="radio" id="52" name="52" value="3"> 03
						<input type="radio" id="52" name="52" value="4"> 04
						<input type="radio" id="52" name="52" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	53	:</strong>Gosto de passar muito tempo imaginando cenas e conversas que nem sempre ocorreram de fato.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="53" name="53" value="1"> 01
						<input type="radio" id="53" name="53" value="2"> 02
						<input type="radio" id="53" name="53" value="3"> 03
						<input type="radio" id="53" name="53" value="4"> 04
						<input type="radio" id="53" name="53" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	54	:</strong>Desejo que alguém me salve de toda essa cansativa confusão.
						</h5>	
					    <br>
						<div  align="center">
54
						<input type="radio" id="54" name="54" value="1"> 01
						<input type="radio" id="54" name="54" value="2"> 02
						<input type="radio" id="54" name="54" value="3"> 03
						<input type="radio" id="54" name="54" value="4"> 04
						<input type="radio" id="54" name="54" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	55	:</strong>Quando as coisas ficam difíceis, geralmente eu desabo e desisto – talvez desista das coisas fácil demais.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="55" name="55" value="1"> 01
						<input type="radio" id="55" name="55" value="2"> 02
						<input type="radio" id="55" name="55" value="3"> 03
						<input type="radio" id="55" name="55" value="4"> 04
						<input type="radio" id="55" name="55" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	56	:</strong>Posso perdoar quase tudo, menos o mau gosto.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="56" name="56" value="1"> 01
						<input type="radio" id="56" name="56" value="2"> 02
						<input type="radio" id="56" name="56" value="3"> 03
						<input type="radio" id="56" name="56" value="4"> 04
						<input type="radio" id="56" name="56" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	57	:</strong>Em geral, não gosto de trabalhar muito ligado a ninguém.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="57" name="57" value="1"> 01
						<input type="radio" id="57" name="57" value="2"> 02
						<input type="radio" id="57" name="57" value="3"> 03
						<input type="radio" id="57" name="57" value="4"> 04
						<input type="radio" id="57" name="57" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	58	:</strong>Encontrar a mim mesmo e ser fiel às minhas necessidades emocionais sempre foram motivações extremamente importantes para mim.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="58" name="58" value="1"> 01
						<input type="radio" id="58" name="58" value="2"> 02
						<input type="radio" id="58" name="58" value="3"> 03
						<input type="radio" id="58" name="58" value="4"> 04
						<input type="radio" id="58" name="58" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta    59	:</strong>Não gosto de ser nem líder nem seguidor.
						</h5>	
					    <br>44
						<div  align="center">

						<input type="radio" id="59" name="59" value="1"> 01
						<input type="radio" id="59" name="59" value="2"> 02
						<input type="radio" id="59" name="59" value="3"> 03
						<input type="radio" id="59" name="59" value="4"> 04
						<input type="radio" id="59" name="59" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	60	:</strong>Sempre tenho uma noção muito clara de minhas intuições, mesmo que não tenha coragem de agir de acordo com elas.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="60" name="60" value="1"> 01
						<input type="radio" id="60" name="60" value="2"> 02
						<input type="radio" id="60" name="60" value="3"> 03
						<input type="radio" id="60" name="60" value="4"> 04
						<input type="radio" id="60" name="60" value="5"> 05
						</div>
						<hr></hr>
						</label>
  <button type="submit" class="btn btn-primary form-control">Enviar Dados</button>
</div>
				</form>
</div>


	


 <?php include 'footer.html';?>

 </body>
</html>