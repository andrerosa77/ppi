<!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">
  
</head>
<body>

  
   <div class="container">
	    	
	    	<br /><br />

	    	<div class="col-md-2"></div>
	    	<div class="col-md-8" id="divlogin">
	    		<h3 align="center">Teste</h3>
	    		<br />
				<form method="post" action="grava_teste.php" id="acesso">
					<div class="form-group">
						<div class="well well-sm"><strong>Etapa 5 de 9</strong><br><br>

						<input type="text" id="etapa" value="5" name="etapa" hidden="">

						<label><h5>	<strong>Pergunta 	61	:</strong>Gosto de analisar as coisas , estudando minuciosamente cada detalhe, até compreendê-las o mais inteiramente possível.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="61" name="61" value="1"> 01
						<input type="radio" id="61" name="61" value="2"> 02
						<input type="radio" id="61" name="61" value="3"> 03
						<input type="radio" id="61" name="61" value="4"> 04
						<input type="radio" id="61" name="61" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	62	:</strong>Sou uma pessoa extremamente reservada que não franqueia a muita gente a entrada em seu mundo.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="62" name="62" value="1"> 01
						<input type="radio" id="62" name="62" value="2"> 02
						<input type="radio" id="62" name="62" value="3"> 03
						<input type="radio" id="62" name="62" value="4"> 04
						<input type="radio" id="62" name="62" value="5"> 05
						</div>
						<hr></hr>
						
						</label>

						<label><h5>	<strong>Pergunta 	63	:</strong>Não me sinto particularmente grande ou poderoso, mas pequeno e invisível: acho que daria um bom espião!

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="63" name="63" value="1"> 01
						<input type="radio" id="63" name="63" value="2"> 02
						<input type="radio" id="63" name="63" value="3"> 03
						<input type="radio" id="63" name="63" value="4"> 04
						<input type="radio" id="63" name="63" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	64	:</strong>As pessoas pensariam que sou louco se soubessem as coisas que eu penso.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="64" name="64" value="1"> 01
						<input type="radio" id="64" name="64" value="2"> 02
						<input type="radio" id="64" name="64" value="3"> 03
						<input type="radio" id="64" name="64" value="4"> 04
						<input type="radio" id="64" name="64" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	65	:</strong>Só se pode tomar uma decisão racional quando se tem informações precisas – mas, aí, a maioria das pessoas, na verdade, não é exatamente racional.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="65" name="65" value="1"> 01
						<input type="radio" id="65" name="65" value="2"> 02
						<input type="radio" id="65" name="65" value="3"> 03
						<input type="radio" id="65" name="65" value="4"> 04
						<input type="radio" id="65" name="65" value="5"> 05
						</div>
						<hr></hr>
						</label>
						
						<label><h5>	<strong>Pergunta 	66	:</strong>Minha família me considera meio estranho ou excêntrico – já ouvi muitas vezes que preciso sair mais.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="66" name="66" value="1"> 01
						<input type="radio" id="66" name="66" value="2"> 02
						<input type="radio" id="66" name="66" value="3"> 03
						<input type="radio" id="66" name="66" value="4"> 04
						<input type="radio" id="66" name="66" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	67	:</strong>Quando quero, sou capaz de falar pelos cotovelos. Porém, na maioria das vezes, prefiro assistir de camarote a toda essa loucura à minha vida.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="67" name="67" value="1"> 01
						<input type="radio" id="67" name="67" value="2"> 02
						<input type="radio" id="67" name="67" value="3"> 03
						<input type="radio" id="67" name="67" value="4"> 04
						<input type="radio" id="67" name="67" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	68	:</strong>Se você precisa resolver um problema, deixe-me trabalhar nele sozinho e depois eu lhe dou uma resposta.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="68" name="68" value="1"> 01
						<input type="radio" id="68" name="68" value="2"> 02
						<input type="radio" id="68" name="68" value="3"> 03
						<input type="radio" id="68" name="68" value="4"> 04
						<input type="radio" id="68" name="68" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	69	:</strong>Quando a gente para para pensar, vê que não há nada mais estranho que o assim chamado comportamento normal.
						</h5>	69
					    <br>
						<div  align="center">
54
						<input type="radio" id="69" name="69" value="1"> 01
						<input type="radio" id="69" name="69" value="2"> 02
						<input type="radio" id="69" name="69" value="3"> 03
						<input type="radio" id="69" name="69" value="4"> 04
						<input type="radio" id="69" name="69" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	70	:</strong>Geralmente passo um bom tempo polindo os projetos em que me envolvo.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="70" name="70" value="1"> 01
						<input type="radio" id="70" name="70" value="2"> 02
						<input type="radio" id="70" name="70" value="3"> 03
						<input type="radio" id="70" name="70" value="4"> 04
						<input type="radio" id="70" name="70" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	71	:</strong>Há muita gente tão ignorante que é incrível que alguma coisa ainda consiga dar certo!
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="71" name="71" value="1"> 01
						<input type="radio" id="71" name="71" value="2"> 02
						<input type="radio" id="71" name="71" value="3"> 03
						<input type="radio" id="71" name="71" value="4"> 04
						<input type="radio" id="71" name="71" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	72	:</strong>Sei muito sobre uma série de coisas e, em algumas áreas, considero-me um expert.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="72" name="72" value="1"> 01
						<input type="radio" id="72" name="72" value="2"> 02
						<input type="radio" id="72" name="72" value="3"> 03
						<input type="radio" id="72" name="72" value="4"> 04
						<input type="radio" id="72" name="72" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	73	:</strong>Sou muito curioso e gosto de investigar o porque das coisas – mesmo as mais óbvias deixam de sê-lo quando você realmente para para analisá-las. 
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="73" name="73" value="1"> 01
						<input type="radio" id="73" name="73" value="2"> 02
						<input type="radio" id="73" name="73" value="3"> 03
						<input type="radio" id="73" name="73" value="4"> 04
						<input type="radio" id="73" name="73" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta    74	:</strong>Minha mente trabalha tanto que às vezes acho que está pegando fogo.
						</h5>	
					    <br>44
						<div  align="center">

						<input type="radio" id="74" name="74" value="1"> 01
						<input type="radio" id="74" name="74" value="2"> 02
						<input type="radio" id="74" name="74" value="3"> 03
						<input type="radio" id="74" name="74" value="4"> 04
						<input type="radio" id="74" name="74" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	75	:</strong>Muitas vezes perco a noção do tempo, pois estou sempre muito concentrado no que faço.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="75" name="75" value="1"> 01
						<input type="radio" id="75" name="75" value="2"> 02
						<input type="radio" id="75" name="75" value="3"> 03
						<input type="radio" id="75" name="75" value="4"> 04
						<input type="radio" id="75" name="75" value="5"> 05
						</div>
						<hr></hr>
						</label>
  <button type="submit" class="btn btn-primary form-control">Enviar Dados</button>
</div>
				</form>
</div>


 <?php include 'footer.html';?>

 </body>
</html>