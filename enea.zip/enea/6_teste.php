<!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">
  
</head>
<body>

  
   <div class="container">
	    	
	    	<br /><br />

	    	<div class="col-md-2"></div>
	    	<div class="col-md-8" id="divlogin">
	    		<h3 align="center">Teste</h3>
	    		<br />
				<form method="post" action="grava_teste.php" id="acesso">
					<div class="form-group">
						<div class="well well-sm"><strong>Etapa 6 de 9</strong><br><br>

						<input type="text" id="etapa" value="6" name="etapa" hidden="">

						<label><h5>	<strong>Pergunta 	76	:</strong>Sinto-me atraído pela autoridade e, ao mesmo tempo, descrente dela.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="76" name="76" value="1"> 01
						<input type="radio" id="76" name="76" value="2"> 02
						<input type="radio" id="76" name="76" value="3"> 03
						<input type="radio" id="76" name="76" value="4"> 04
						<input type="radio" id="76" name="76" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	77	:</strong>Sou muito afetivo apesar de quase nunca demonstrar o que sinto  a não ser aos mais íntimos , mesmo assim nem sempre.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="77" name="77" value="1"> 01
						<input type="radio" id="77" name="77" value="2"> 02
						<input type="radio" id="77" name="77" value="3"> 03
						<input type="radio" id="77" name="77" value="4"> 04
						<input type="radio" id="77" name="77" value="5"> 05
						</div>
						<hr></hr>
						
						</label>

						<label><h5>	<strong>Pergunta 	78	:</strong>Se cometo um erro, tenho medo que todos pulem na minha garganta.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="78" name="78" value="1"> 01
						<input type="radio" id="78" name="78" value="2"> 02
						<input type="radio" id="78" name="78" value="3"> 03
						<input type="radio" id="78" name="78" value="4"> 04
						<input type="radio" id="78" name="78" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	79	:</strong>Sinto-me mais seguro fazendo o que se espera de mim do que trabalhando por conta própria.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="79" name="79" value="1"> 01
						<input type="radio" id="79" name="79" value="2"> 02
						<input type="radio" id="79" name="79" value="3"> 03
						<input type="radio" id="79" name="79" value="4"> 04
						<input type="radio" id="79" name="79" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	80	:</strong>Posso não concordar sempre com as regras – e nem sempre segui-las – mas quero saber em que consistem.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="80" name="80" value="1"> 01
						<input type="radio" id="80" name="80" value="2"> 02
						<input type="radio" id="80" name="80" value="3"> 03
						<input type="radio" id="80" name="80" value="4"> 04
						<input type="radio" id="80" name="80" value="5"> 05
						</div>
						<hr></hr>
						</label>
						
						<label><h5>	<strong>Pergunta 	81	:</strong>A primeira impressão que as pessoas me causam geralmente é muito forte e difícil de mudar.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="81" name="81" value="1"> 01
						<input type="radio" id="81" name="81" value="2"> 02
						<input type="radio" id="81" name="81" value="3"> 03
						<input type="radio" id="81" name="81" value="4"> 04
						<input type="radio" id="81" name="81" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	82	:</strong>As poucas pessoas a quem admiro são para mim os meus heróis.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="82" name="82" value="1"> 01
						<input type="radio" id="82" name="82" value="2"> 02
						<input type="radio" id="82" name="82" value="3"> 03
						<input type="radio" id="82" name="82" value="4"> 04
						<input type="radio" id="82" name="82" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	83	:</strong>Não gosto de tomar decisões importantes, mas tampouco quero que alguém as tome por mim!
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="83" name="83" value="1"> 01
						<input type="radio" id="83" name="83" value="2"> 02
						<input type="radio" id="83" name="83" value="3"> 03
						<input type="radio" id="83" name="83" value="4"> 04
						<input type="radio" id="83" name="83" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	84	:</strong>Algumas pessoas consideram-me nervoso e irrequieto – mas não sabem da missa a metade.
						</h5>
					    <br>
						<div  align="center">
						<input type="radio" id="84" name="84" value="1"> 01
						<input type="radio" id="84" name="84" value="2"> 02
						<input type="radio" id="84" name="84" value="3"> 03
						<input type="radio" id="84" name="84" value="4"> 04
						<input type="radio" id="84" name="84" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	85	:</strong>Sei o quanto eu posso estragar as coisas; portanto suspeitar do que os outros estão “aprontando” tem muito sentido para mim.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="85" name="85" value="1"> 01
						<input type="radio" id="85" name="85" value="2"> 02
						<input type="radio" id="85" name="85" value="3"> 03
						<input type="radio" id="85" name="85" value="4"> 04
						<input type="radio" id="85" name="85" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	86	:</strong>Quero confiar nas pessoas, mas muitas vezes vejo-me questionando suas intenções.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="86" name="86" value="1"> 01
						<input type="radio" id="86" name="86" value="2"> 02
						<input type="radio" id="86" name="86" value="3"> 03
						<input type="radio" id="86" name="86" value="4"> 04
						<input type="radio" id="86" name="86" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	87	:</strong>Sou de trabalhar duro: vou batalhando até fazer o que tem que ser feito.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="87" name="87" value="1"> 01
						<input type="radio" id="87" name="87" value="2"> 02
						<input type="radio" id="87" name="87" value="3"> 03
						<input type="radio" id="87" name="87" value="4"> 04
						<input type="radio" id="87" name="87" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	88	:</strong>Sondo a opinião daqueles em quem confio antes de tomar uma grande decisão
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="88" name="88" value="1"> 01
						<input type="radio" id="88" name="88" value="2"> 02
						<input type="radio" id="88" name="88" value="3"> 03
						<input type="radio" id="88" name="88" value="4"> 04
						<input type="radio" id="88" name="88" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta    89	:</strong>É realmente curioso: sou muitas vezes cético, e até cínico, em relação a muitas coisas e, de repente, mudo e começo a acreditar completamente em tudo.
						</h5>	
					    <br>44
						<div  align="center">

						<input type="radio" id="89" name="89" value="1"> 01
						<input type="radio" id="89" name="89" value="2"> 02
						<input type="radio" id="89" name="89" value="3"> 03
						<input type="radio" id="89" name="89" value="4"> 04
						<input type="radio" id="89" name="89" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	90	:</strong>Meu sobrenome deveria ser Ansiedade
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="90" name="90" value="1"> 01
						<input type="radio" id="90" name="90" value="2"> 02
						<input type="radio" id="90" name="90" value="3"> 03
						<input type="radio" id="90" name="90" value="4"> 04
						<input type="radio" id="90" name="90" value="5"> 05
						</div>
						<hr></hr>
						</label>
  <button type="submit" class="btn btn-primary form-control">Enviar Dados</button>
</div>
				</form>
</div>


 <?php include 'footer.html';?>

 </body>
</html>