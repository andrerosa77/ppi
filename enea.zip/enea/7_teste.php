<!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">
  
</head>
<body>

  
   <div class="container">
	    	
	    	<br /><br />

	    	<div class="col-md-2"></div>
	    	<div class="col-md-8" id="divlogin">
	    		<h3 align="center">Teste</h3>
	    		<br />
				<form method="post" action="grava_teste.php" id="acesso">
					<div class="form-group">
						<div class="well well-sm"><strong>Etapa 7 de 9</strong><br><br>

						<input type="text" id="etapa" value="7" name="etapa" hidden="">

						<label><h5>	<strong>Pergunta 	91	:</strong>Adoro viajar e descobrir diferentes tipos de pratos, de pessoas, de experiências – todo o fantástico turbilhão da vida!
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="91" name="91" value="1"> 01
						<input type="radio" id="91" name="91" value="2"> 02
						<input type="radio" id="91" name="91" value="3"> 03
						<input type="radio" id="91" name="91" value="4"> 04
						<input type="radio" id="91" name="91" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	92	:</strong>Minha agenda normalmente é cheia e eu gosto que seja assim: não quero que a grama cresça debaixo de meus pés.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="92" name="92" value="1"> 01
						<input type="radio" id="92" name="92" value="2"> 02
						<input type="radio" id="92" name="92" value="3"> 03
						<input type="radio" id="92" name="92" value="4"> 04
						<input type="radio" id="92" name="92" value="5"> 05
						</div>
						<hr></hr>
						
						</label>

						<label><h5>	<strong>Pergunta 	93	:</strong>Para mim o que importa é a emoção e a variedade, mais que o conforto e a segurança – que eu, alias, não desprezo quando encontro.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="93" name="93" value="1"> 01
						<input type="radio" id="93" name="93" value="2"> 02
						<input type="radio" id="93" name="93" value="3"> 03
						<input type="radio" id="93" name="93" value="4"> 04
						<input type="radio" id="93" name="93" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	94	:</strong>Minha mente está sempre tagarelando – às vezes parece que penso dez coisas de uma vez!

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="94" name="94" value="1"> 01
						<input type="radio" id="94" name="94" value="2"> 02
						<input type="radio" id="94" name="94" value="3"> 03
						<input type="radio" id="94" name="94" value="4"> 04
						<input type="radio" id="94" name="94" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	95	:</strong>Se tem uma coisa que não suporto é entediar-me – procuro dar um jeito de não me aborrecer nunca.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="95" name="95" value="1"> 01
						<input type="radio" id="95" name="95" value="2"> 02
						<input type="radio" id="95" name="95" value="3"> 03
						<input type="radio" id="95" name="95" value="4"> 04
						<input type="radio" id="95" name="95" value="5"> 05
						</div>
						<hr></hr>
						</label>
						
						<label><h5>	<strong>Pergunta 		:</strong>Sou de entrar de cabeça nos relacionamentos – mas quando acabam, acabam.
						</h5>	96
					    <br>
						<div  align="center">

						<input type="radio" id="96" name="96" value="1"> 01
						<input type="radio" id="96" name="96" value="2"> 02
						<input type="radio" id="96" name="96" value="3"> 03
						<input type="radio" id="96" name="96" value="4"> 04
						<input type="radio" id="96" name="96" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	97	:</strong>Sou curioso e aventureiro – geralmente sou o primeiro a experimentar coisas novas e interessantes.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="97" name="97" value="1"> 01
						<input type="radio" id="97" name="97" value="2"> 02
						<input type="radio" id="97" name="97" value="3"> 03
						<input type="radio" id="97" name="97" value="4"> 04
						<input type="radio" id="97" name="97" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	98	:</strong>Quando já não gosto de fazer alguma coisa, eu paro de fazê-la.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="98" name="98" value="1"> 01
						<input type="radio" id="98" name="98" value="2"> 02
						<input type="radio" id="98" name="98" value="3"> 03
						<input type="radio" id="98" name="98" value="4"> 04
						<input type="radio" id="98" name="98" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	99	:</strong>Não sou só uma pessoa “divertida”: tenho um lado sério, até sombrio, só que não gosto de mexer muito com ele.
						</h5>
					    <br>
						<div  align="center">
54
						<input type="radio" id="99" name="99" value="1"> 01
						<input type="radio" id="99" name="99" value="2"> 02
						<input type="radio" id="99" name="99" value="3"> 03
						<input type="radio" id="99" name="99" value="4"> 04
						<input type="radio" id="99" name="99" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	100	:</strong>Sou bom no geral, mas não tanto nos pequenos detalhes; gosto mais de pensar para chegar a novas idéias que me envolver com sua execução.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="100" name="100" value="1"> 01
						<input type="radio" id="100" name="100" value="2"> 02
						<input type="radio" id="100" name="100" value="3"> 03
						<input type="radio" id="100" name="100" value="4"> 04
						<input type="radio" id="100" name="100" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	101	:</strong>Quando realmente quero uma coisa, quase sempre descubro um meio de consegui-la.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="101" name="101" value="1"> 01
						<input type="radio" id="101" name="101" value="2"> 02
						<input type="radio" id="101" name="101" value="3"> 03
						<input type="radio" id="101" name="101" value="4"> 04
						<input type="radio" id="101" name="101" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	72	:</strong>De vez em quando entro em “baixo astral”, mas sempre saio logo dele.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="102" name="102" value="1"> 01
						<input type="radio" id="102" name="102" value="2"> 02
						<input type="radio" id="102" name="102" value="3"> 03
						<input type="radio" id="102" name="102" value="4"> 04
						<input type="radio" id="102" name="102" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	103	:</strong>Um dos meus maiores problemas é que sou muito distraído e as vezes me disperso demais.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="103" name="103" value="1"> 01
						<input type="radio" id="103" name="103" value="2"> 02
						<input type="radio" id="103" name="103" value="3"> 03
						<input type="radio" id="103" name="103" value="4"> 04
						<input type="radio" id="103" name="103" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta    104	:</strong>Tenho tendência a gastar mais do que deveria.
						</h5>	
					    <br>44
						<div  align="center">

						<input type="radio" id="104" name="104" value="1"> 01
						<input type="radio" id="104" name="104" value="2"> 02
						<input type="radio" id="104" name="104" value="3"> 03
						<input type="radio" id="104" name="104" value="4"> 04
						<input type="radio" id="104" name="104" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	105	:</strong>Acho ótimo estar com as pessoas – contanto que elas queiram ir aonde eu quero
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="105" name="105" value="1"> 01
						<input type="radio" id="105" name="105" value="2"> 02
						<input type="radio" id="105" name="105" value="3"> 03
						<input type="radio" id="105" name="105" value="4"> 04
						<input type="radio" id="105" name="105" value="5"> 05
						</div>
						<hr></hr>
						</label>
  <button type="submit" class="btn btn-primary form-control">Enviar Dados</button>
</div>
				</form>
</div>


 <?php include 'footer.html';?>

 </body>
</html>