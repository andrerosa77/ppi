<!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">
  
</head>
<body>

  
   <div class="container">
	    	
	    	<br /><br />

	    	<div class="col-md-2"></div>
	    	<div class="col-md-8" id="divlogin">
	    		<h3 align="center">Teste</h3>
	    		<br />
				<form method="post" action="grava_teste.php" id="acesso">
					<div class="form-group">
						<div class="well well-sm"><strong>Etapa 8 de 9</strong><br><br>
						
						<input type="text" id="etapa" value="8" name="etapa" hidden="">

						<label><h5>	<strong>Pergunta 	106	:</strong>Sou extremamente independente e não gosto de precisar de ninguém para as coisas realmente importantes.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="106" name="106" value="1"> 01
						<input type="radio" id="106" name="106" value="2"> 02
						<input type="radio" id="106" name="106" value="3"> 03
						<input type="radio" id="106" name="106" value="4"> 04
						<input type="radio" id="106" name="106" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	107	:</strong>Sou da opinião de que “é preciso quebrar alguns ovos quando se quer fazer uma omelete”
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="107" name="107" value="1"> 01
						<input type="radio" id="107" name="107" value="2"> 02
						<input type="radio" id="107" name="107" value="3"> 03
						<input type="radio" id="107" name="107" value="4"> 04
						<input type="radio" id="107" name="107" value="5"> 05
						</div>
						<hr></hr>
						
						</label>

						<label><h5>	<strong>Pergunta 	108	:</strong>Quando gosto das pessoas, geralmente penso nelas como “minha gente” e acho que devo gostar atento aos seus interesses.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="108" name="108" value="1"> 01
						<input type="radio" id="108" name="108" value="2"> 02
						<input type="radio" id="108" name="108" value="3"> 03
						<input type="radio" id="108" name="108" value="4"> 04
						<input type="radio" id="108" name="108" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 		:</strong>Sei como conseguir as coisas – sei como recompensar e como pressionar as pessoas para que façam o que precisa ser feito.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="109" name="109" value="1"> 01
						<input type="radio" id="109" name="109" value="2"> 02
						<input type="radio" id="109" name="109" value="3"> 03
						<input type="radio" id="109" name="109" value="4"> 04
						<input type="radio" id="109" name="109" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	110	:</strong>Não tenho simpatia pelos fracos e vacilantes – a fraqueza sempre é um convite aos problemas.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="110" name="110" value="1"> 01
						<input type="radio" id="110" name="110" value="2"> 02
						<input type="radio" id="110" name="110" value="3"> 03
						<input type="radio" id="110" name="110" value="4"> 04
						<input type="radio" id="110" name="110" value="5"> 05
						</div>
						<hr></hr>
						</label>
						
						<label><h5>	<strong>Pergunta 		:</strong>Sou muito determinado e não sou de recuar nem desistir facilmente.
						</h5>	96
					    <br>
						<div  align="center">

						<input type="radio" id="111" name="111" value="1"> 01
						<input type="radio" id="111" name="111" value="2"> 02
						<input type="radio" id="111" name="111" value="3"> 03
						<input type="radio" id="111" name="111" value="4"> 04
						<input type="radio" id="111" name="111" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 		:</strong>Nada me deixa mais orgulhoso que ver alguém que acolhi sob a minha asa conseguir vencer sozinho.
						</h5>	
					    <br>112
						<div  align="center">

						<input type="radio" id="112" name="112" value="1"> 01
						<input type="radio" id="112" name="112" value="2"> 02
						<input type="radio" id="112" name="112" value="3"> 03
						<input type="radio" id="112" name="112" value="4"> 04
						<input type="radio" id="112" name="112" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	113	:</strong>Tenho um lado terno, até um pouco sentimental, que demonstro para muita pouca gente.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="113" name="113" value="1"> 01
						<input type="radio" id="113" name="113" value="2"> 02
						<input type="radio" id="113" name="113" value="3"> 03
						<input type="radio" id="113" name="113" value="4"> 04
						<input type="radio" id="113" name="113" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 		:</strong>AS pessoas que me conhecem apreciam o fato de eu ser objetivo e dizer exatamente o que penso.
						</h5>
					    <br>
						<div  align="center">
54
						<input type="radio" id="114" name="114" value="1"> 01
						<input type="radio" id="114" name="114" value="2"> 02
						<input type="radio" id="114" name="114" value="3"> 03
						<input type="radio" id="114" name="114" value="4"> 04
						<input type="radio" id="114" name="114" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	115	:</strong>Tive de trabalhar muito para conseguir tudo que tenho – acho que batalhar é muito bom porque nos dá resistência e nos faz ter certeza do que queremos.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="115" name="115" value="1"> 01
						<input type="radio" id="115" name="115" value="2"> 02
						<input type="radio" id="115" name="115" value="3"> 03
						<input type="radio" id="115" name="115" value="4"> 04
						<input type="radio" id="115" name="115" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	116	:</strong>Vejo-me como um desafiador, alguém que faz as pessoas abandonarem a comodidade para dar o melhor de si.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="116" name="116" value="1"> 01
						<input type="radio" id="116" name="116" value="2"> 02
						<input type="radio" id="116" name="116" value="3"> 03
						<input type="radio" id="116" name="116" value="4"> 04
						<input type="radio" id="116" name="116" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	117	:</strong>Meu senso de humor é direto, às vezes até um pouco rude, embora eu ache que a maioria das pessoas é demasiado pudica e suscetível. 
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="117" name="117" value="1"> 01
						<input type="radio" id="117" name="117" value="2"> 02
						<input type="radio" id="117" name="117" value="3"> 03
						<input type="radio" id="117" name="117" value="4"> 04
						<input type="radio" id="117" name="117" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	118	:</strong>Meus acessos de raiva são monumentais, mas logo se dissipam.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="118" name="118" value="1"> 01
						<input type="radio" id="118" name="118" value="2"> 02
						<input type="radio" id="118" name="118" value="3"> 03
						<input type="radio" id="118" name="118" value="4"> 04
						<input type="radio" id="118" name="118" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta    119	:</strong>Sinto-me mais vivo quando faço o que os outros julgam impossível: gosto de ir até o limite e ver se consigo desafiar as probabilidades. 
						</h5>	
					    <br>44
						<div  align="center">

						<input type="radio" id="119" name="119" value="1"> 01
						<input type="radio" id="119" name="119" value="2"> 02
						<input type="radio" id="119" name="119" value="3"> 03
						<input type="radio" id="119" name="119" value="4"> 04
						<input type="radio" id="119" name="119" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	120	:</strong>A corda sempre tem de estourar de um lado – e eu não quero que seja do meu.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="120" name="120" value="1"> 01
						<input type="radio" id="120" name="120" value="2"> 02
						<input type="radio" id="120" name="120" value="3"> 03
						<input type="radio" id="120" name="120" value="4"> 04
						<input type="radio" id="120" name="120" value="5"> 05
						</div>
						<hr></hr>
						</label>
  <button type="submit" class="btn btn-primary form-control">Enviar Dados</button>
</div>
				</form>
</div>


 <?php include 'footer.html';?>

 </body>
</html>