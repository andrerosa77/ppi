<!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">
  
</head>
<body>

  
   <div class="container">
	    	
	    	<br /><br />

	    	<div class="col-md-2"></div>
	    	<div class="col-md-8" id="divlogin">
	    		<h3 align="center">Teste</h3>
	    		<br />
				<form method="post" action="grava_teste.php" id="acesso">
					<div class="form-group">
						<div class="well well-sm"><strong>Etapa 9 de 9</strong><br><br>

						<input type="text" id="etapa" value="9" name="etapa" hidden="">

						<label><h5>	<strong>Pergunta 	121	:</strong>O que as pessoas gostam em mim é a sensação de segurança que lhes transmito.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="121" name="121" value="1"> 01
						<input type="radio" id="121" name="121" value="2"> 02
						<input type="radio" id="121" name="121" value="3"> 03
						<input type="radio" id="121" name="121" value="4"> 04
						<input type="radio" id="121" name="121" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	122	:</strong>Não me incomodo de estar com as pessoas nem de estar só – para mim tanto faz, contanto que esteja em paz comigo mesmo.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="122" name="122" value="1"> 01
						<input type="radio" id="122" name="122" value="2"> 02
						<input type="radio" id="122" name="122" value="3"> 03
						<input type="radio" id="122" name="122" value="4"> 04
						<input type="radio" id="122" name="122" value="5"> 05
						</div>
						<hr></hr>
						
						</label>

						<label><h5>	<strong>Pergunta 	123	:</strong>Encontrei um certo equilíbrio na vida e não vejo razão para perturbá-lo.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="123" name="123" value="1"> 01
						<input type="radio" id="123" name="123" value="2"> 02
						<input type="radio" id="123" name="123" value="3"> 03
						<input type="radio" id="123" name="123" value="4"> 04
						<input type="radio" id="123" name="123" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta  124		:</strong>Estar “a vontade”, em todos os sentidos da expressão, é algo que me agrada muito.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="124" name="124" value="1"> 01
						<input type="radio" id="124" name="124" value="2"> 02
						<input type="radio" id="124" name="124" value="3"> 03
						<input type="radio" id="124" name="124" value="4"> 04
						<input type="radio" id="124" name="124" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	125	:</strong>Prefiro concordar do que criar uma cena.

						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="125" name="125" value="1"> 01
						<input type="radio" id="125" name="125" value="2"> 02
						<input type="radio" id="125" name="125" value="3"> 03
						<input type="radio" id="125" name="125" value="4"> 04
						<input type="radio" id="125" name="125" value="5"> 05
						</div>
						<hr></hr>
						</label>
						
						<label><h5>	<strong>Pergunta 	126	:</strong>Não sei exatamente como, mas não deixo que as coisas me atinjam.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="126" name="126" value="1"> 01
						<input type="radio" id="126" name="126" value="2"> 02
						<input type="radio" id="126" name="126" value="3"> 03
						<input type="radio" id="126" name="126" value="4"> 04
						<input type="radio" id="126" name="126" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	127	:</strong>Sou uma pessoa fácil de agradar e geralmente me contento com o que tenho. 
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="127" name="127" value="1"> 01
						<input type="radio" id="127" name="127" value="2"> 02
						<input type="radio" id="127" name="127" value="3"> 03
						<input type="radio" id="127" name="127" value="4"> 04
						<input type="radio" id="127" name="127" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	128	:</strong>Já me disseram que sou distraído e alheio às coisas – o fato é que eu as entendo, mas simplesmente não quero reagir.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="128" name="128" value="1"> 01
						<input type="radio" id="128" name="128" value="2"> 02
						<input type="radio" id="128" name="128" value="3"> 03
						<input type="radio" id="128" name="128" value="4"> 04
						<input type="radio" id="128" name="128" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	129	:</strong>Não me acho particularmente obstinado, mas as pessoas dizem que eu às vezes sou teimoso quando tomo uma decisão.
						</h5>
					    <br>
						<div  align="center">

						<input type="radio" id="129" name="129" value="1"> 01
						<input type="radio" id="129" name="129" value="2"> 02
						<input type="radio" id="129" name="129" value="3"> 03
						<input type="radio" id="129" name="129" value="4"> 04
						<input type="radio" id="129" name="129" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	130	:</strong>A maioria das pessoas parece excitar-se muito fácil; eu sou muito mais estável. 
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="130" name="130" value="1"> 01
						<input type="radio" id="130" name="130" value="2"> 02
						<input type="radio" id="130" name="130" value="3"> 03
						<input type="radio" id="130" name="130" value="4"> 04
						<input type="radio" id="130" name="130" value="5"> 05
						</div>
						<hr></hr>
						</label>


						<label><h5>	<strong>Pergunta 	131	:</strong>É preciso aceitar o que a vida nos dá; afinal, não há muito o que fazer!
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="131" name="131" value="1"> 01
						<input type="radio" id="131" name="131" value="2"> 02
						<input type="radio" id="131" name="131" value="3"> 03
						<input type="radio" id="131" name="131" value="4"> 04
						<input type="radio" id="131" name="131" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	132	:</strong>Sou capaz de entender diferentes pontos de vista e geralmente concordo com as pessoas mais que discordo delas. 
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="132" name="132" value="1"> 01
						<input type="radio" id="132" name="132" value="2"> 02
						<input type="radio" id="132" name="132" value="3"> 03
						<input type="radio" id="132" name="132" value="4"> 04
						<input type="radio" id="132" name="132" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	133	:</strong>Acredito que se devem realçar os fatores positivos em vez de ficar martelando os negativos. 
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="133" name="133" value="1"> 01
						<input type="radio" id="133" name="133" value="2"> 02
						<input type="radio" id="133" name="133" value="3"> 03
						<input type="radio" id="133" name="133" value="4"> 04
						<input type="radio" id="133" name="133" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta    134	:</strong>Tenho uma espécie de filosofia de vida que me orienta e conforta em épocas difíceis.  
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="134" name="134" value="1"> 01
						<input type="radio" id="134" name="134" value="2"> 02
						<input type="radio" id="134" name="134" value="3"> 03
						<input type="radio" id="134" name="134" value="4"> 04
						<input type="radio" id="134" name="134" value="5"> 05
						</div>
						<hr></hr>
						</label>

						<label><h5>	<strong>Pergunta 	135	:</strong>Durante o dia, faço tudo que precisa ser feito, mas quando o dia acaba, eu relaxo mesmo.
						</h5>	
					    <br>
						<div  align="center">

						<input type="radio" id="135" name="135" value="1"> 01
						<input type="radio" id="135" name="135" value="2"> 02
						<input type="radio" id="135" name="135" value="3"> 03
						<input type="radio" id="135" name="135" value="4"> 04
						<input type="radio" id="135" name="135" value="5"> 05
						</div>
						<hr></hr>
						</label>
  <button type="submit" class="btn btn-primary form-control">Enviar Dados</button>
</div>
				</form>
</div>


 <?php include 'footer.html';?>

 </body>
</html>