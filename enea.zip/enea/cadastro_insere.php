<?php
 include_once('conn.php');
?>

<!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">
 



</head>
<body>
<?php include 'menu.html';?>
<br><br><br>



<div class="container">
  <div class="row">
<div class="col-sm2"></div>
<div class="col-sm8"></div>
<div class="panel panel-info class">
      <div class="panel-heading"><h4 align="center">Cadastre-se</h4></div>
      <div class="panel-body" id="controla">
   

<form id="form1" action="/action_page.php">
    <div class="form-group" id='formulario'>
       <label for="nome'">Nome/Razao Social:</label>
      <input type="text" class="form-control" id="nome" placeholder="Digite Nome/Razao Social" name="nome" required>

      <label for="fantasia">Nome Fantasia</label>
      <input type="text" class="form-control" id="fantasia" placeholder="Digite nome fantasia" name="fantasia" required>
      <br>

      <label for="tipo_cli">Tipo Cliente:</label>
      <select id="tipo_cli" name="tipo_cli"  required" >
      <option selected value="0">Tipo Cliente</option>
       <option value="J">Júridica</option>
      <option value="F">Física</option>
     
      </select>
      <br>    

         <label for="cpf">CPF/CNPJ:</label>
      <input type="text" class="form-control" id="cpf" placeholder="Digite CPF..." name="cpf" disabled>
      </div>

      

   
      

      <label for="contato">Nome Fantasia</label>
      <input type="text" class="form-control" id="contato" placeholder="Digite nome de contato" name="contato" required>
      
      <label for="telefone">Telefone:</label>
      <input type="text" class="form-control" id="telefone" placeholder="Digite o telefone" name="telefone" required>
        <label for="segmento">Segmento:</label>
      <input type="text" class="form-control" id="telefone" placeholder="Digite o Segmento" name="Segmento" required>

     
      <label for="email1">Email 1:</label>
      <input type="email" class="form-control" id="email1" placeholder="Digite email" name="email1">
    


      <label for="email2">Email 2:</label>
      <input type="email" class="form-control" id="email2" placeholder="Digite email" name="email1">
   
    <div class="form-group">
      <label for="senha">Password:</label>
      <input type="password" class="form-control" id="senha" placeholder="Digite a senha" name="senha">
    </div>
    <div class="checkbox" align="center">
      <label><input type="checkbox" name="aceite" required> Aceito os Termos de Serviço </label>
    </div>
    <div align="center">
    <button type="button" class="btn btn-success">Cadastrar</button>
    <button type="button" class="btn btn-danger">Limpar</button>
    </div>
  </form>
 </div>
 <div class="col-sm2"></div>
 </div>
 </div>
</div>


 
 <?php include 'footer.html';?>

 </body>
</html>
