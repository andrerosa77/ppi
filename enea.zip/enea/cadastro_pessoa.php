<!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">
 

>

</head>
<body>
<?php include 'menu.html';?>
<br><br><br>



<div class="container">
  <div class="row">
<div class="col-sm2"></div>
<div class="col-sm8"></div>
<div class="panel panel-info class">
      <div class="panel-heading"><h4 align="center">Cadastre-se</h4></div>
      <div class="panel-body" id="controla">
   

<form id="form1" action="/action_page.php">
    <div class="form-group" id='formulario'>
       <label for="nome'">Nome:</label>
      <input type="text" class="form-control" id="nome" placeholder="Digite Nome/Razao Social" name="nome" required>

     

      <label for="tipo_cli">Tipo Cliente:</label>
      <select id="tipo_cli" name="tipo_cli"  required " >
      <option selected value="0">Tipo Cliente</option>
       <option value="J">Júridica</option>
      <option value="F">Física</option>
     
      </select>
      <br>    

      <label for="rg">RG:</label>
      <input type="text" class="form-control" id="rg" placeholder="Digite CPF..." name="rg" >
      </div>

      <label for="cpf">CPF/CNPJ:</label>
      <input type="text" class="form-control" id="cpf" placeholder="Digite CPF..." name="cpf" >
      </div>

        <label for="email">Email 1:</label>
      <input type="email1" class="form-control" id="email" placeholder="Digite email" name="email">
    
      <label for="telefone">Telefone:</label>
      <input type="text" class="form-control" id="telefone" placeholder="Digite o telefone" name="telefone" required>
   
      

      <label for="ender">Endereço</label>
      <input type="text" class="form-control" id="ender" placeholder="Digite nome o endereço" name="enderco" required>
      
      <label for="numero">Numero:</label>
      <input type="text" class="form-control" id="numero" placeholder="Digite o numero" name="numero" required>


      <label for="cidade">Cidade:</label>
      <input type="text" class="form-control" id="cidade" placeholder="Digite a cidade" name="cidade" required>

      <label for="bairro">Bairro:</label>
      <input type="text" class="form-control" id="bairro" placeholder="Digite o' bairro" name="bairro" required>   
  
      <label for="estado">Estado:</label>
      <input type="text" class="form-control" id="estado" placeholder="Digite o estado" name="estado" required>  

      <label for="cep">Cep:</label>
      <input type="text" class="form-control" id="cep" placeholder="Digite o cep" name="cep">

      <label for="campl">Compl :</label>
      <input type="text" class="form-control" id="campl" placeholder="Digite o Complemento" name="campl">

      
      <label for="campl">Compl :</label>
      <input type="text" class="form-control" id="campl" placeholder="Digite o Complemento" name="campl">
   
    <div class="form-group">
      <label for="senha">Password:</label>
      <input type="password" class="form-control" id="senha" placeholder="Digite a senha" name="senha">
    </div>
    <div class="checkbox" align="center">
      <label><input type="checkbox" name="aceite" required> Aceito os Termos de Serviço </label>
    </div>
    <div align="center">
    <button type="button" class="btn btn-success">Cadastrar</button>
    <button type="button" class="btn btn-danger">Limpar</button>
    </div>
  </form>
 </div>
 <div class="col-sm2"></div>
 </div>
 </div>
</div>


 
 <?php include 'footer.html';?>

 </body>
</html>


