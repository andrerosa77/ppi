 <!DOCTYPE html>
<html>
<head>
  <title>Enea Cloud Serivces </title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
  <link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">

  
</head>
<body>
 <?php include 'menu.html';?>

<body>
  <br>
  <br>
  <br>
<div class="container">
    <div class="row">
        <div class="col-sm-3 col-md-3">
            <div class="panel-group">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse"><span class="glyphicon glyphicon-folder-close">
                            </span>Painel ADM</a>
                        </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse in">
                        <div class="panel-body">
                            <table class="table">
                                <tr>
                                    <td>
                                        <span class="glyphicon glyphicon-pencil text-primary"></span><a href="convite.php">Convites</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="glyphicon glyphicon-flash text-success"></span><a href="report.php">Analises</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="glyphicon glyphicon-file text-info"></span><a href="#">Pesquisa</a>
                                    </td>

                                </tr>
                                <tr>
                                    <td>
                                        
                                  <span class="glyphicon glyphicon-user"></span>
                                  <a href="#">Minha Conta</a> 
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
               <div class="col-sm-9 col-md-9">
            <div class="well">
                
           <div class="row">
              <div class="col-md-2" id="divlogin"></div>
              <div class="col-md-6" id="divlogin" align="center">
          <h3>Area de Envio de Convites</h3>
          <br>
           <form method="post" action="" id="acesso">
          <div class="form-group">
            
          </div>
           <div class="form-group">
            <input type="text" class="form-control" id="convidado" name="email" placeholder="Digite o nome do convidado" required="requiored">
            

          <div class="form-group">
            <input type="email" class="form-control" id="email" name="email" placeholder="Email" required="requiored">
            
          </div>
          
          
          
          <button type="submit" class="btn btn-primary form-control">Enviar Convidar</button>
        </form>
      </div>
      <div class="col-md-2" id="divlogin"></div>
      </div>

            </div>
        </div>
    </div>
</div>
        


<?php include 'footer.html';?>

 </body>
</html>