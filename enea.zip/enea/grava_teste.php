<?php
    if (isset($_POST['etapa']) ) {
      
      $etapa=$_POST['etapa'];

if ($etapa==1){
	$inicio=1;
	$fim=15;
} 

else if ($etapa==2){
	$inicio=16;
	$fim=30;
}

else if ($etapa==3){
	$inicio=31;
	$fim=45;
}

else if ($etapa==4){
	$inicio=46;
	$fim=60;
}

else if ($etapa==5){
	$inicio=61;
	$fim=75;
}
else if ($etapa==6){
	$inicio=76;
	$fim=90;
}

else if ($etapa==7){
	$inicio=91;
	$fim=105;
}
else if ($etapa==8){
	$inicio=106;
	$fim=120;
}

else if ($etapa==8){
	$inicio=121;
	$fim=135;
}

while ($inicio <=$fim){
  echo $inicio;
  echo "<br>";
  echo $valor=$_POST[$inicio];
  $inicio=$inicio+1;
}

/*

      if ($etapa==1){

      	header("location:2_teste.php"); 
      }

      else if ($etapa==2){

      	header("location:3_teste.php"); 
      }
        else if ($etapa==3){

      	header("location:4_teste.php"); 
      }

  else if ($etapa==4){

      	header("location:5_teste.php"); 
      }

  else if ($etapa==5){

      	header("location:6_teste.php"); 
      }

  else if ($etapa==6){

      	header("location:7_teste.php"); 
      }

  else if ($etapa==7){

      	header("location:8_teste.php"); 
      }

  else if ($etapa==8){

      	header("location:9_teste.php"); 
      }

 else if ($etapa==8){

      	header("location:teste_resultado.php"); 
      }
*/
    }
