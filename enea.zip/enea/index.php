<!DOCTYPE html>
<html>
<head>
	<title>Enea Cloud Serivces </title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="./css/estilo.css"> 
	<link rel="stylesheet" type="text/css" href="./lib/bootstrap/css/bootstrap.min.css">


	
</head>
<body>

 <?php include 'menu.html';?>
 <?php include 'corpo.html';?>
 <?php include 'footer.html';?>

 </body>
</html>