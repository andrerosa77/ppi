
<?php
 include_once('conn.php');
?>
<?php
 // recuperando
 $chave = $_GET['chave'];
 
    if ($chave=="SIM")
    {
    	ECHO "OK";
    }
    else
    {
        ECHO "ERRO";	
    }
/*
http://localhost/enea/valida_convite.php?chave=asas
*/


echo date("d/m/Y H:i:s ");
echo "<br>";
echo md5(date("d/m/Y H:i:s "));
?>
